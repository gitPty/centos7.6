# kube-prometheus

This is the helm chart equivalent of `contrib/kube-prometheus`.

# Prerequisites

Requires helm >= 2.5.0
