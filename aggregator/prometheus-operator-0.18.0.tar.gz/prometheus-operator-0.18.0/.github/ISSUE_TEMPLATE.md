**What did you do?**

**What did you expect to see?**

**What did you see instead? Under which circumstances?**

**Environment**

* Kubernetes version information:

	insert output of `kubectl version` here

* Kubernetes cluster kind: 

	insert how you created your cluster: kops, bootkube, tectonic-installer, etc.

* Manifests:

```
insert manifests relevant to the issue
```

* Prometheus Operator Logs:

```
insert Prometheus Operator logs relevant to the issue here
```
