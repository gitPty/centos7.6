### This directory will include all generated manifests if no specific options are given
