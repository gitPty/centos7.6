---
name: Enhancement Request
about: Suggest an enhancement to the Metrics Server

---
<!-- Please only use this template for submitting enhancement requests -->

**What would you like to be added**:

**Why is this needed**:

<!-- DO NOT EDIT BELOW THIS LINE -->
/kind feature